
<div style="position: absolute;width: 100%;z-index: 100000;top: 100px;">
    <?php if($errors->count() > 0): ?>

        <div class="alert alert-danger">
            <?php echo $errors->first(); ?>

        </div>

    <?php elseif(Session::has('success')): ?>

        <div class="alert alert-success">
            <?php echo Session::get('success'); ?>

        </div>

    <?php elseif(Session::has('warning')): ?>

        <div class="alert alert-warning">
            <?php echo Session::get('warning'); ?>

        </div>

    <?php elseif(Session::has('danger')): ?>

        <div class="alert alert-danger">
            <?php echo Session::get('danger'); ?>

        </div>

    <?php endif; ?>
</div>