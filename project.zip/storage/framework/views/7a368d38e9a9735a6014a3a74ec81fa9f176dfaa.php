<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body_content'); ?>

    <div class="container" style="min-height: 600px">
        <div class="row" style="margin-top: 80px">
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">Pick a location below</div>
                    </div>
                    <div class="panel-body text-center">
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'awolowo hall'])); ?>">Awo Hall</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'department of chemistry'])); ?>">Yellow house</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'white house'])); ?>">white house</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Faculty of Law basement'])); ?>">Faculty of Law basement</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Students Union Building'])); ?>">Students Union Building</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Humanities'])); ?>">Humanities</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Humanities car park'])); ?>">Humanities car park</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Forks and Fingers'])); ?>">Forks and Fingers</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Skye Bank Single ATM Machine'])); ?>">Skye Bank Single ATM Machine</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Bims Catering Services'])); ?>">Bims Catering Services</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Risky Joint'])); ?>">Risky Joint</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Moremi buttery'])); ?>">Moremi buttery</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Bus stop 1'])); ?>">Bus stop 1</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Bus stop 2'])); ?>">Bus stop 2</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Health Centre'])); ?>">Health Centre</a>
                        <a class="btn btn-success btn-xs" href="<?php echo e(route('find-centre', ['location' => 'Oduduwa hall'])); ?>">Amphitheatre</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div style="width: 100%; height: 450px;">
                    <?php echo Mapper::render(0); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>