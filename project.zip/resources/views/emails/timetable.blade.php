<body>
Here is your timetable oo:

<img src="<?php echo $message->embed(asset('images/home_map.png')); ?>">
</body>