@extends('template')

@section('page_styles')
@endsection

@section('body_content')

    <div class="container" style="min-height: 600px">
        <div class="row" style="margin-top: 80px">
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title">Pick a location below</div>
                    </div>
                    <div class="panel-body text-center">
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'awolowo hall']) }}">Awo Hall</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'department of chemistry']) }}">Yellow house</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'white house']) }}">white house</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Faculty of Law basement']) }}">Faculty of Law basement</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Students Union Building']) }}">Students Union Building</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Humanities']) }}">Humanities</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Humanities car park']) }}">Humanities car park</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Forks and Fingers']) }}">Forks and Fingers</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Skye Bank Single ATM Machine']) }}">Skye Bank Single ATM Machine</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Bims Catering Services']) }}">Bims Catering Services</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Risky Joint']) }}">Risky Joint</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Moremi buttery']) }}">Moremi buttery</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Bus stop 1']) }}">Bus stop 1</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Bus stop 2']) }}">Bus stop 2</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Health Centre']) }}">Health Centre</a>
                        <a class="btn btn-success btn-xs" href="{{ route('find-centre', ['location' => 'Oduduwa hall']) }}">Amphitheatre</a>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div style="width: 100%; height: 450px;">
                    {!! Mapper::render(0) !!}
                </div>
            </div>
        </div>
    </div>

@endsection

@section('page_scripts')

@endsection