<?php

namespace App\Http\Controllers;

use App\TimeTable;
use App\UserTimeTable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ScheduleController extends Controller
{
    public function sendTimeTable()
    {
        foreach(UserTimeTable::get() as $user)
        {
            if($timetable = TimeTable::where('department', $user->department)->where('level', $user->level)->where('semester', $user->semester)->first())
            {

                Mail::send(['html' => 'emails.timetable'], [], function($message)
                {
                    $message->to('babsmacheda@ymail.com')->subject(config('app.name').' - Your Timetable');
                });

            } else {
                //Send mail for no timetable
            }
        }
    }
}
